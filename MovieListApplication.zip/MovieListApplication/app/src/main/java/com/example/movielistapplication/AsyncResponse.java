package com.example.movielistapplication;

import java.util.ArrayList;

public interface AsyncResponse {
    void processFinish(ArrayList<MovieResultObj> outPut);
}
